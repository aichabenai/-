
document.getElementById('quizForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let score = 0;

    // Check question 1
    const q1Answer = document.querySelector('input[name="q1"]:checked');
    if (q1Answer && q1Answer.value === "أبو القاسم الشابي") {
        score++;
    }

    // Check question 2
    const q2Answer = document.querySelector('input[name="q2"]').value.trim();
    if (q2Answer === "فلا بد أن يستجيب القدر") {
        score++;
    }

    // Show result
    document.getElementById('score').textContent = score;
    document.getElementById('result').style.display = 'block';
});
